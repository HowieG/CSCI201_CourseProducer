package client;

public interface FactoryReporter {
	public String report();
}